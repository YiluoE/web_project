create view v_test as
(
select `u`.`name` AS `name`, `u`.`credit` AS `credit`, `u`.`sex` AS `sex`
from `byles`.`user` `u`
where (`u`.`sex` = '女'));

