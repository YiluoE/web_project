create
    definer = root@localhost procedure score(IN s int, OUT scoreout varchar(3))
begin

	case
		when s>=90 then
			set scoreout='A';
		when s>=80 then
			set scoreout='B';
		when s>=70 then
			set scoreout='C';
		when s>=60 then
			set scoreout='D';
		else
			set scoreout='E';
		end case;
end;

