create
    definer = root@localhost procedure createFBNC()
begin
	
	declare i decimal(65) default 1;
	declare c decimal(65);
	declare x decimal(65) default 1;
	declare y decimal(65) default 1;
	
	
	while i<100 do
		insert into stble_fibonacci(id,num) values (i,x);
	
		set c=x;
		set x=y;
		set y=c+y;
		
		set i = i+1;
	end while;
end;

