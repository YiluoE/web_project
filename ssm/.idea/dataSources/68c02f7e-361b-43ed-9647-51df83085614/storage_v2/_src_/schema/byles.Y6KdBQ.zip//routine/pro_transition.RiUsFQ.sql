create
    definer = root@localhost procedure pro_transition(IN input int, OUT output varchar(3))
begin
	case input
		when 1 then
			set output='星期一';
		when 2 then
			set output='星期二';
		when 3 then
			set output='星期三';
		when 4 then
			set output='星期四';
		when 5 then
			set output='星期五';
		when 6 then
			set output='星期六';
		else
			set output='星期日';
	end case;
	
end;

