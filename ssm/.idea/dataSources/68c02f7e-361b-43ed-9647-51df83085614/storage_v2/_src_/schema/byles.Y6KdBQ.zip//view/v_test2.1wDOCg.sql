create view v_test2 as
(
select `byles`.`user`.`city` AS `city`, `byles`.`user`.`name` AS `name`
from `byles`.`user`
group by `byles`.`user`.`city`);

