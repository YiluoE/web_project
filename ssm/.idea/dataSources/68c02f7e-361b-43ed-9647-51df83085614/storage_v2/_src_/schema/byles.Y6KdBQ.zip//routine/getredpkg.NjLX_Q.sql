create
    definer = root@localhost procedure getredpkg(IN _account varchar(10), IN _money double, IN _num int, IN _type int)
begin
	declare i int;
	declare redpkgnum int default 0;
	declare r double;
	declare sum double default 0;
	declare tempnum int;
	declare temp_redpkg double default 0;
	declare max double default 0;
	
	set _money = _money*100;
	set _money = _money-_num;
	
	set i = _num;
	while(i>1) do -- 生红包个数-1个随机数用于划分权重
		set r = rand();
		set sum = (sum+r);
		insert into temp(id,ran) values (_num-i+1,r);
		
		set i = i-1;
	end while;
	
	select count(1) into tempnum from temp;
	set i = tempnum;
	while(i>0) do
		select ran into r from temp where id=_num-i;
		set temp_redpkg = round( _money*(r/sum) );
		set _money = _money-temp_redpkg;
		update temp set redpkg=temp_redpkg where id=_num-i;
		
		set i = i-1;
	end while;
	
	insert into temp(id,redpkg) values (_num,_money); -- 生成最后一个红包
	
	-- 对生成的每个红包做最后的处理
	select count(1) into tempnum from temp;
	set i = tempnum;
	
	while(i>0) do
		select redpkg into temp_redpkg from temp where id=_num-i+1;
		set temp_redpkg = temp_redpkg+1;
		set temp_redpkg = temp_redpkg / 100;
		
		update temp set redpkg=temp_redpkg where id=_num-i+1;
		
		set i = i-1;
	end while;
	
	select max(redpkg) into max from temp;

	select count(1) into redpkgnum from redpkg;
	set redpkgnum = redpkgnum+1;
	
	insert into redpkg(pid,account,money,num,createtime,type)
	values (redpkgnum,_account,_money,_num,sysdate(),_type);
	
	set i = _num;
	if(_type=1) then
		while i>0 do
		
			select redpkg into temp_redpkg from temp where id=_num-i+1;
			
			insert into rptransinfo(pid,money,ord,best)
			values (redpkgnum,temp_redpkg,_num-i+1,_type);	-- 1 最佳手气 0 非最佳手气
			
			set i = i-1;
		end while;
		
	elseif _type=2 then
	
		while(i>0) do
			insert into rptransinfo(pid,money,ord)
			values (redpkgnum,_money,_num-i+1);
		
			set i = i-1;
		end while;
	end if;
	
end;

