create view d2010v as
(
select `u`.`userID`   AS `userID`,
       `u`.`name`     AS `name`,
       `u`.`ename`    AS `ename`,
       `u`.`personId` AS `personId`,
       `u`.`sex`      AS `sex`,
       `u`.`credit`   AS `credit`,
       `u`.`city`     AS `city`
from `byles`.`user` `u`);

