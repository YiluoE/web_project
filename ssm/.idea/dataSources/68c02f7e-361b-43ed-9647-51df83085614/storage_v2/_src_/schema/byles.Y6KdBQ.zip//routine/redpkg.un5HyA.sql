create
    definer = root@localhost procedure redpkg()
begin

	declare money double default 10*100; -- 划分金额单元为分
	declare num int default 3;
	
	declare r1 double;
	declare r2 double;
	declare r3 double;
	declare sum double;
	declare rp1 double;
	declare rp2 double;
	declare rp3 double;
-- 	declare i int; -- 为什么前面有个set语句就会报错 set money = (money-num);
	
	set money = money-num;
	set r1 = rand();
	set r2 = rand();
	set r3 = rand();
	set sum = r1+r2+r3;	
	
	set rp1 = round( money*(r1/sum) );
	set rp2 = round( money*(r2/sum) );
	
	set money = money-rp1;
	set money = money-rp2;
	
	set rp3 = money;
	
	set rp1 = rp1+1;
	set rp2 = rp2+1;
	set rp3 = rp3+1;
	
	set rp1 = rp1/100;
	set rp2 = rp2/100;
	set rp3 = rp3/100;
	
	select rp1,rp2,rp3;
	
-- 	set i = num;
--  	while i>0 do
-- 		
--  	
--  		set i=i-1;
--  	end while;

--  -- 游标
-- 	-- 接受游标数据的变量
-- 	declare c_name varchar(8);	
-- 	declare c_ename varchar(8);
-- 	
-- 	declare sign int default 0; -- 游标状态标志位
-- 	declare cur cursor for select name,ename from user; -- 创建游标
-- 	
-- 	declare continue handler for not found set sign=1; -- 将标志位绑定到游标
-- 	
-- 	open cur;
-- 	cur_loop:loop
-- 		
-- 		fetch cur into c_name,c_ename; -- 提取游标数据
-- 		
-- 		if sign=1 then
-- 			leave cur_loop;
-- 		end if;
-- 		
-- 		
-- 		
-- 	end loop cur_loop;
-- 	close cur;
end;

