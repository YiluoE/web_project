create view userv as
(
select `byles`.`transinfo`.`id` AS `id`
from `byles`.`transinfo`
         join (`byles`.`user` left join `byles`.`card` on ((`byles`.`user`.`userID` = `byles`.`card`.`userId`)))
where ((`byles`.`transinfo`.`cardNo` = `byles`.`card`.`cardNo`) and
       (`byles`.`card`.`userId` = `byles`.`user`.`userID`) and (`byles`.`user`.`sex` = '女')));

